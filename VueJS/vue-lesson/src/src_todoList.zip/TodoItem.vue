<template>
  <li class="theItem">{{xyz}}</li>
</template>

<script>
  export default {
    props: ['xyz'],
  }
</script>

<style>
  .theItem{
    background: #abc;
    cursor: pointer;
    font: 18px Calibri;
    margin: 5px 0px;
    padding: 5px;
  }

  .theItem:hover{
    background: #cba;
  }




</style>

