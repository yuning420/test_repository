<template>
  <div>
    <h1>Products</h1>
    <!-- <h3>{{$route.params.sn}}</h3> -->
    <h3>{{sn}}</h3>
  </div>
</template>

<script>
const items = {
  10: 'Hat',
  20: 'T-shirt',
  30: 'Shoes',
  40: 'Bags',
  40: 'Accessories',
};
export default {
  computed: { //要記得包在computed裡
    sn(){
      return items[this.$route.params.sn];
    },
  }
};
</script>

<style scoped>
  h1{
    font: 40px Comic Sans MS;
    color: goldenrod;
  }
  
</style>