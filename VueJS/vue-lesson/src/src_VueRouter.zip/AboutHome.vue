<template>
  <div>
    <h2>Home</h2>
  </div>
</template>