<html>
  <body>

    <!-- GET表單 -->
    <form method="POST" action="memQueryR.php">

    <!-- POST表單 -->
    <!--<form method="post" action="Post.php">-->

        <br/>
        帳號:<input type="text" name="account" /><br/>
        密碼:<input type="text" name="pwd" /><br/>

      <br/>
      <input type="submit" value="送出" />


    </form>

  </body>
</html>